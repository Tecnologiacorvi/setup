@echo off
title CORVI Control de Asistencia - Instalador Oficial
cd /d "%~dp0"

echo ============================================================
echo    CORVI CONTROL DE ASISTENCIA - INSTALACION AUTOMATICA
echo                CORVI CONSULTORES S.A.S.
echo ============================================================
echo.

:: 1. Verificar instalacion de Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo [!] Se requiere Python instalado en su equipo para continuar.
    echo Se abrira la pagina oficial de descarga a continuacion...
    start https://www.python.org/downloads/
    echo Por favor instale Python marcando la casilla "Add Python to PATH"
    echo y luego vuelva a hacer doble clic en este instalador.
    echo.
    pause
    exit /b 1
)

:: 2. Instalar dependencias graficas requeridas
echo [*] Preparando entorno de telemetria...
python -m pip install Pillow --quiet >nul 2>&1

:: 3. Directorio de instalacion en AppData local del usuario
set "INSTALL_DIR=%LOCALAPPDATA%\CORVI_Asistencia"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: 4. Copiar archivos locales o sincronizar desde GitHub privado
if exist "%~dp0Archivos_del_Sistema\corvi_asistencia.py" (
    echo [*] Copiando archivos de la aplicacion...
    xcopy /E /I /Y "%~dp0Archivos_del_Sistema\*" "%INSTALL_DIR%\" >nul
) else (
    echo [*] Sincronizando componentes oficiales desde la nube CORVI...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$headers = @{ 'Authorization' = 'token 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'; 'Accept' = 'application/vnd.github.v3.raw' }; Invoke-WebRequest -Uri 'https://api.github.com/repos/Tecnologiacorvi/corvi-control-asistencia/contents/corvi_asistencia.py' -Headers $headers -OutFile '%INSTALL_DIR%\corvi_asistencia.py'; Invoke-WebRequest -Uri 'https://api.github.com/repos/Tecnologiacorvi/corvi-control-asistencia/contents/Archivos_del_Sistema/iniciar_asistencia.vbs' -Headers $headers -OutFile '%INSTALL_DIR%\iniciar_asistencia.vbs'; Invoke-WebRequest -Uri 'https://api.github.com/repos/Tecnologiacorvi/corvi-control-asistencia/contents/Archivos_del_Sistema/icono_corvi.ico' -Headers $headers -OutFile '%INSTALL_DIR%\icono_corvi.ico'" >nul 2>&1
)

:: 5. Asegurar presencia del icono corporativo oficial
if exist "%~dp0icono_corvi.ico" (
    copy /Y "%~dp0icono_corvi.ico" "%INSTALL_DIR%\" >nul
)

:: 6. Crear acceso directo con el Logo Oficial de CORVI en el Escritorio
echo [*] Creando acceso directo con logo oficial en su Escritorio...
powershell -NoProfile -ExecutionPolicy Bypass -NonInteractive -WindowStyle Hidden -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Control de Asistencia.lnk')); $s.TargetPath = 'wscript.exe'; $s.Arguments = '\"%INSTALL_DIR%\iniciar_asistencia.vbs\"'; $s.WorkingDirectory = '%INSTALL_DIR%'; if (Test-Path '%INSTALL_DIR%\icono_corvi.ico') { $s.IconLocation = '%INSTALL_DIR%\icono_corvi.ico,0' }; $s.Save()" >nul 2>&1

:: 7. Arrancar aplicacion en segundo plano (modo silencioso, cero consolas)
echo.
echo ============================================================
echo   INSTALACION COMPLETADA CON EXITO
echo   Se ha creado el acceso directo "Control de Asistencia"
echo   en su Escritorio con el logo oficial de CORVI.
echo ============================================================
echo.
cd /d "%INSTALL_DIR%"
start "" wscript.exe "%INSTALL_DIR%\iniciar_asistencia.vbs"
timeout /t 3 >nul
exit
