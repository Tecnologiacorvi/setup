@echo off
setlocal EnableDelayedExpansion
title Instalador CORVI Control de Asistencia

echo ============================================================
echo    CORVI CONTROL DE ASISTENCIA - INSTALACION OFICIAL
echo                CORVI CONSULTORES S.A.S.
echo ============================================================
echo.
echo [*] Deteniendo procesos anteriores si existieran...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq *CORVI*" >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1

:: Limpiar residuos viejos de NSIS en Menu Inicio
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\CORVI" (
    rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\CORVI" >nul 2>&1
)

set "SOURCE_DIR=%~dp0"
set "INSTALL_DIR=%LOCALAPPDATA%\CORVI_Asistencia"

echo [*] Configurando aplicacion en su equipo...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: Copiar archivos a la carpeta definitiva
xcopy "%SOURCE_DIR%*" "%INSTALL_DIR%\" /E /I /Y /Q >nul 2>&1

:: Validar Pillow si python esta en el equipo
python -m pip install Pillow --quiet >nul 2>&1

echo [*] Creando acceso directo en el Escritorio...
set "VBS_LNK=%TEMP%\mk_corvi_lnk.vbs"

echo Set W = CreateObject("WScript.Shell") > "%VBS_LNK%"
echo Set F = CreateObject("Scripting.FileSystemObject") >> "%VBS_LNK%"
echo P = "%INSTALL_DIR%" >> "%VBS_LNK%"
echo I = P ^& "\icono_corvi.ico,0" >> "%VBS_LNK%"
echo. >> "%VBS_LNK%"
echo D1 = W.SpecialFolders("Desktop") >> "%VBS_LNK%"
echo If F.FolderExists(D1) Then >> "%VBS_LNK%"
echo   Set L = W.CreateShortcut(D1 ^& "\Control de Asistencia.lnk") >> "%VBS_LNK%"
echo   L.TargetPath = "wscript.exe" >> "%VBS_LNK%"
echo   L.Arguments = Chr(34) ^& P ^& "\iniciar_asistencia.vbs" ^& Chr(34) >> "%VBS_LNK%"
echo   L.WorkingDirectory = P >> "%VBS_LNK%"
echo   L.IconLocation = I >> "%VBS_LNK%"
echo   L.Description = "CORVI Control de Asistencia" >> "%VBS_LNK%"
echo   L.Save >> "%VBS_LNK%"
echo End If >> "%VBS_LNK%"
echo. >> "%VBS_LNK%"
echo D2 = W.ExpandEnvironmentStrings("%%USERPROFILE%%\OneDrive\Escritorio") >> "%VBS_LNK%"
echo If F.FolderExists(D2) Then >> "%VBS_LNK%"
echo   Set L2 = W.CreateShortcut(D2 ^& "\Control de Asistencia.lnk") >> "%VBS_LNK%"
echo   L2.TargetPath = "wscript.exe" >> "%VBS_LNK%"
echo   L2.Arguments = Chr(34) ^& P ^& "\iniciar_asistencia.vbs" ^& Chr(34) >> "%VBS_LNK%"
echo   L2.WorkingDirectory = P >> "%VBS_LNK%"
echo   L2.IconLocation = I >> "%VBS_LNK%"
echo   L2.Description = "CORVI Control de Asistencia" >> "%VBS_LNK%"
echo   L2.Save >> "%VBS_LNK%"
echo End If >> "%VBS_LNK%"

cscript //nologo "%VBS_LNK%"
del /f /q "%VBS_LNK%" >nul 2>&1

ie4uinit.exe -show >nul 2>&1

echo [*] Iniciando panel de control de asistencia...
cd /d "%INSTALL_DIR%"
start "" wscript.exe "%INSTALL_DIR%\iniciar_asistencia.vbs"

echo.
echo ============================================================
echo   INSTALACION COMPLETADA CON EXITO
echo   Acceso directo creado en el Escritorio con Logo Oficial.
echo ============================================================
timeout /t 3 >nul
exit
