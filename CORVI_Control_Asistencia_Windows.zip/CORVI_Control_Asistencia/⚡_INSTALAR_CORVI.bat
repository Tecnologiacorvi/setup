@echo off
setlocal EnableDelayedExpansion
title Instalador CORVI Control de Asistencia

echo ============================================================
echo    CORVI CONTROL DE ASISTENCIA - INSTALACION OFICIAL
echo                CORVI CONSULTORES S.A.S.
echo ============================================================
echo.
echo [*] Deteniendo procesos anteriores si existieran...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq *CORVI*" >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1

:: Limpiar residuos viejos de NSIS en Menu Inicio
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\CORVI" (
    rmdir /s /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\CORVI" >nul 2>&1
)

set "SOURCE_DIR=%~dp0"
set "INSTALL_DIR=%LOCALAPPDATA%\CORVI_Asistencia"

echo [*] Configurando aplicacion y motor oficial en su equipo...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: Copiar todos los archivos y carpetas (incluyendo python embebido)
xcopy "%SOURCE_DIR%*" "%INSTALL_DIR%\" /E /I /Y /Q >nul 2>&1

:: Verificar que el archivo principal y el motor quedaron listos
if not exist "%INSTALL_DIR%\python\pythonw.exe" (
    echo.
    echo [ERROR] No se pudo copiar el motor de ejecucion.
    echo Asegurese de haber descomprimido el archivo ZIP antes de ejecutar.
    pause
    exit /b 1
)

echo [*] Creando acceso directo en el Escritorio con logo oficial...
set "VBS_SHORTCUT=%TEMP%\create_corvi_shortcut_%RANDOM%.vbs"
(
echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
echo sDesktop = oWS.SpecialFolders^("Desktop"^)
echo sAppDir = oWS.ExpandEnvironmentStrings^("%%LOCALAPPDATA%%\CORVI_Asistencia"^)
echo sIco = sAppDir ^& "\icono_corvi.ico,0"
echo Set oLink = oWS.CreateShortcut^(sDesktop ^& "\Control de Asistencia.lnk"^)
echo oLink.TargetPath = "wscript.exe"
echo oLink.Arguments = """" ^& sAppDir ^& "\iniciar_asistencia.vbs" ^& """"
echo oLink.WorkingDirectory = sAppDir
echo oLink.IconLocation = sIco
echo oLink.Description = "CORVI Control de Asistencia"
echo oLink.Save
echo Set oLink2 = oWS.CreateShortcut^(oWS.SpecialFolders^("Programs"^) ^& "\Control de Asistencia.lnk"^)
echo oLink2.TargetPath = "wscript.exe"
echo oLink2.Arguments = """" ^& sAppDir ^& "\iniciar_asistencia.vbs" ^& """"
echo oLink2.WorkingDirectory = sAppDir
echo oLink2.IconLocation = sIco
echo oLink2.Description = "CORVI Control de Asistencia"
echo oLink2.Save
) > "%VBS_SHORTCUT%"
cscript //nologo "%VBS_SHORTCUT%" >nul 2>&1
del /f /q "%VBS_SHORTCUT%" >nul 2>&1

:: Forzar refresco visual de iconos en el explorador de Windows
ie4uinit.exe -show >nul 2>&1

echo [*] Iniciando panel de control de asistencia...
cd /d "%INSTALL_DIR%"
start "" wscript.exe "%INSTALL_DIR%\iniciar_asistencia.vbs"

echo.
echo ============================================================
echo   INSTALACION COMPLETADA CON EXITO (100%%)
echo   Acceso directo creado en el Escritorio con Logo Oficial.
echo ============================================================
timeout /t 3 >nul
exit
