# 🛡️ CORVI AUDITOR & TIME TRACKER — MANUAL OPERATIVO

**Firma:** CORVI CONSULTORES S.A.S.  
**Ubicación del Sistema:** `/home/davidrp/Escritorio/09_SISTEMA_AUDITORIA_TRABAJO_CORVI/`  
**Estado:** Probado, validado y 100% operativo en Linux Mint y Windows 10/11.

---

## 📌 1. PROPÓSITO Y ALCANCE TÉCNICO

Esta herramienta resuelve de forma automatizada e inalterable el control de jornada, telemetría de productividad y auditoría operativa de colaboradores remotos de CORVI:

1. **Elimina la fricción manual de Clockify:** El colaborador no tiene que tipear a mano lo que hace; el sistema registra en tiempo real el título de las ventanas activas, software contable (Siigo, Odoo, Excel) y carpetas de trabajo.
2. **Detección objetiva de Inactividad (AFK - Away From Keyboard):** Si pasan más de 5 minutos sin pulsación de teclado o movimiento del ratón, el contador laboral efectivo se detiene automáticamente y suma al registro de "Ausencia del Equipo".
3. **Auditoría de Conectividad a Internet (Control de Excusas Técnicas):**
   - El sistema comprueba de forma continua la conectividad mediante sockets TCP ultralivianos (a servidores globales DNS 8.8.8.8 y 1.1.1.1 con latencia real de ~6 ms).
   - Registra el porcentaje de disponibilidad de red (`% Uptime`).
   - Si se presenta una caída real de internet, registra la hora exacta de inicio, fin y duración en minutos/segundos.
   - **Prueba irrefutable:** Si el colaborador dice *"no pude avanzar porque se me cayó el internet toda la mañana"*, el reporte muestra si la conexión estuvo 100% activa o si realmente existió un corte y de cuántos minutos fue.
4. **Control de empresas y conflicto de intereses:** Detecta si el auxiliar está trabajando en contabilidades o documentos de empresas que **no pertenecen a CORVI**.
5. **Auditoría de Entorno Completo, Música y Audio en Segundo Plano:**
   - Si el colaborador escucha YouTube o Spotify en segundo plano mientras trabaja en Excel/Siigo o atiende la oficina virtual, el sistema audita de forma continua el stream de audio.
   - Extrae el título exacto del video o canción reproducida (ej. *Coldplay - The Scientist*, *Best of Alternative Rock 90s & 2000s*).
   - Registra el tiempo exacto reproducido como **"Música en Segundo Plano"** (acompañamiento sonoro) sin penalizarlo como tiempo ocioso ni como AFK mientras esté en jornada activa.
6. **Inventario Concurrente de Pestañas Múltiples y Perfiles de Chrome:**
   - Detecta y audita todas las pestañas abiertas en simultáneo a través de los diferentes perfiles del navegador (Default, Profile 1, etc.): Instagram, WhatsApp Web, Clockify, Google Antigravity AI, etc.
   - Brinda visibilidad total al supervisor sin depender únicamente de la ventana en foco.
7. **Detección Inteligente de Reuniones vs. Standby en Oficina Virtual (WorkAdventure, Meet, Teams, Zoom, Skype):**
   - **En Reunión Real:** Cuando el colaborador está reunido con Linda o compañeros en WorkAdventure (con burbuja de llamada, tarjetas de participantes activas o pantalla compartida) o en Meet/Teams/Zoom, el sistema reconoce el tiempo como **100% Productivo / En Reunión**, evitando falsos positivos de inactividad mientras atiende la llamada.
   - **Avatar Solo / Standby (>5 min):** Si el colaborador deja su muñeco solo en el escritorio de WorkAdventure sin compañeros ni audio y pasa más de 5 minutos sin tocar mouse/teclado, el sistema **NUNCA lo disfraza de reunión**: lo clasifica como `🚨 Ausencia / Standby en Oficina Virtual` y dispara una Alerta Roja en el reporte diario.
8. **Captura de Pantalla periódica (Cada 5 minutos):**
   - ~96 fotos al día en formato **WebP de alta compresión** (~60 KB por captura).
   - Consumo diario ínfimo: **menos de 5 a 6 MB por usuario al día** (un mes completo pesa menos de 130 MB en Google Drive).
   - Nitidez total en 1080p para auditar balances, pantallas compartidas, llamadas activas y pestañas de todos los perfiles.
9. **Rendimiento de Hardware Inmaculado:**
   - Consumo medido en producción: **0.0% de CPU y 43.4 MB de RAM** (la cuarta parte de una sola pestaña de Chrome). Cero impacto en la velocidad del equipo.
10. **Destino y Respaldo a Google Drive:**
   - La estructura está organizada por fecha: `REGISTROS_JORNADA/YYYY-MM-DD/`.
   - Se copia/sincroniza a la carpeta compartida de Google Drive: `Contratos, Afiliaciones y Trabajadores de Nómina / Auditoría y Telemetría`.

---

## 🚀 2. CÓMO INICIAR EL SISTEMA

### 🆕 Activación Única por Primera Vez (Onboarding Automático):
1. Al abrir el sistema por primera vez en cualquier computador nuevo, se despliega una pantalla corporativa de **Configuración de Puesto Remoto**.
2. El colaborador ingresa:
   - Nombre completo (ej. *Sergio Acosta*)
   - Cédula de ciudadanía
   - Cargo asignado (*Auxiliar Contable y Tributario*)
   - Correo electrónico de contacto
3. Al dar clic en **«Guardar y Vincular Puesto de Trabajo»**:
   - El equipo queda permanentemente sellado a nombre de ese colaborador.
   - Se despacha una alerta inmediata al correo de David Rodríguez (`r.davidmauriciop@gmail.com`) con los datos del equipo y fecha/hora de vinculación.
   - A partir de ese momento, **el formulario nunca más vuelve a aparecer** en ese equipo; el sistema entra directo al tablero diario.

### En Linux Mint / Ubuntu:
1. Abrir terminal o hacer doble clic en:
   ```bash
   /home/davidrp/Escritorio/09_SISTEMA_AUDITORIA_TRABAJO_CORVI/iniciar_auditor.sh
   ```
2. O ejecutar directamente:
   ```bash
   python3 /home/davidrp/Escritorio/09_SISTEMA_AUDITORIA_TRABAJO_CORVI/corvi_auditor.py
   ```
3. Se abrirá automáticamente una ventana de aplicación dedicada de Google Chrome con la consola de control.

### En Windows 10 / 11 (Auxiliares remotos):
1. Hacer doble clic en el archivo:
   ```cmd
   iniciar_auditor.bat
   ```
2. Auto-instala librerías si faltan y abre la interfaz en el navegador en `http://127.0.0.1:8765`.

---

## 🎛️ 3. USO DE LA INTERFAZ POR EL COLABORADOR

La interfaz cuenta con 3 botones de control y monitoreo en vivo:

* **▶ INICIAR JORNADA (Botón Verde):**
  - Arranca el cronómetro de trabajo efectivo.
  - Activa la telemetría de ventanas cada 10 segundos.
  - Toma la primera captura de pantalla de comprobación de inicio de turno.
  - Lanza notificación de escritorio nativa confirmando inicio.
* **⏸ PAUSA / ALMUERZO / TIEMPO PERSONAL (Botón Amarillo):**
  - Congela el contador de tiempo laboral pagado.
  - Apaga temporalmente las capturas de pantalla para **garantizar el derecho a la intimidad** durante su descanso, citas médicas o almuerzo.
* **⏹ FINALIZAR DÍA (Botón Rojo):**
  - Cierra la jornada.
  - Genera automáticamente el archivo consolidado `REPORTE_JORNADA.html` y el JSON estructurado.
  - Deja los archivos listos para revisión de David y Linda.
* **📸 Captura de Prueba:** Permite forzar una captura inmediata para validar que la pantalla y el encuadre están operando correctamente.

---

## 📊 4. ESTRUCTURA DE ARCHIVOS GENERADOS

Cada día trabajado genera la siguiente estructura dentro de `REGISTROS_JORNADA/`:

```
REGISTROS_JORNADA/
└── 2026-11-12/
    ├── capturas/
    │   ├── 08-00-12_Sergio_Acosta.webp
    │   ├── 08-15-00_Sergio_Acosta.webp
    │   ├── 08-30-00_Sergio_Acosta.webp
    │   └── ... (32 capturas de 1080p WebP de 100 KB)
    ├── telemetria.jsonl          (Registro cronológico segundo a segundo)
    ├── REPORTE_JORNADA.json      (Datos tabulados para integración n8n o BI)
    └── REPORTE_JORNADA.html      (Reporte visual ejecutivo para David y Linda)
```

### El Reporte Visual Ejecutivo (`REPORTE_JORNADA.html`):
- Tarjetas de Gala con los colores corporativos de CORVI (Borgoña `#160826` a `#9e0e47`).
- Desglose de:
  - Tiempo Total en Turno.
  - Tiempo Productivo Efectivo (digitación y uso de software).
  - Tiempo de Inactividad / Ausencia (AFK).
  - Porcentaje de Eficiencia Global.
  - Tabla de proporción de tiempo por cada software (Siigo, Odoo, Excel, DIAN, etc.).
  - Registro de Alertas (desvíos, ocio, ventanas anómalas).
  - **Galería interactiva con modal Lightbox:** Clic en cualquier captura para verla en pantalla completa en alta resolución.

---

## ⚙️ 5. PERSONALIZACIÓN Y CLIENTES EN `config.json`

En el archivo `config.json` se pueden agregar los clientes oficiales de CORVI para que el sistema reconozca automáticamente sus nombres en las pestañas del navegador y balances de Excel:

```json
{
    "colaborador_nombre": "Sergio Acosta",
    "colaborador_cargo": "Auxiliar Contable y Tributario",
    "intervalo_telemetria_seg": 10,
    "intervalo_captura_min": 15,
    "umbral_inactividad_afk_seg": 300,
    "clientes_autorizados": [
        "CIDERAL", "KDT", "BOCANOS", "FUMIPARTES", "CORVI", "SIIGO", "ODOO", "DIAN"
    ]
}
```

---

## ⚖️ 6. FASE SIGUIENTE (BLINDAJE JURÍDICO)

Una vez probado y aceptado el software por David y Linda, se procederá a:
1. Elaborar el **Otrosí / Anexo Contractual de Telemetría Laboral y Control de Rendimiento** (bajo Ley 1581/2012, Ley 1221/2008 y CST).
2. Firma formal con los colaboradores actuales y futuros antes de activar el sistema en sus estaciones de trabajo.
