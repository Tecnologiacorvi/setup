' =============================================================================
' CORVI CONTROL DE ASISTENCIA — LANZADOR SILENCIOSO WINDOWS (MODO DISCRETO)
' Ejecuta el motor mediante pythonw.exe sin abrir ninguna consola CMD ni ventana negra.
' =============================================================================
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = currentDir

' Ejecución completamente oculta (ventana 0, no bloqueante)
WshShell.Run "pythonw.exe """ & currentDir & "\corvi_asistencia.py""", 0, False
