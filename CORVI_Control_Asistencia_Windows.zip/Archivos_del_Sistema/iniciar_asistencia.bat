@echo off
cd /d "%~dp0"
if exist iniciar_asistencia.vbs (
    start "" wscript.exe iniciar_asistencia.vbs
) else (
    start "" pythonw corvi_asistencia.py
)
exit
